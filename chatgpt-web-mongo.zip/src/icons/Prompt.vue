<template>
  <div class="text-[#142D6E] dark:text-[#3a71ff]">
    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 24">
      <g fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M5 7l5 5l-5 5" />
        <path d="M13 17h6" />
      </g>
    </svg>
  </div>
</template>
